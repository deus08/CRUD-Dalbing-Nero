﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace EntityFramework.Models
{
    public class Casting
    {
        [Key]
        [Display(Name = "Casting ID")]

        public int CastingID { get; set; }
        
        [Required]
        [Display (Name = "Nombre del casting")]
        public string Nombre { get; set; }

        [Display (Name = "Fecha de contratacion")]
        public DateTime FechaContratacion { get; set;}

        [Display(Name = "Estado activo")]
        public bool EstadoActivo { get; set; }

    }
}
