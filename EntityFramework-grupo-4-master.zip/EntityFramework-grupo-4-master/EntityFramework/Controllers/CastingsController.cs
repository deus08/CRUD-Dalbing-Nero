﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using EntityFramework.Data;
using EntityFramework.Models;

namespace EntityFramework.Controllers
{
    public class CastingsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CastingsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Castings
        public async Task<IActionResult> Index()
        {
            return View(await _context.castings.ToListAsync());
        }

        // GET: Castings/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var casting = await _context.castings
                .FirstOrDefaultAsync(m => m.CastingID == id);
            if (casting == null)
            {
                return NotFound();
            }

            return View(casting);
        }

        // GET: Castings/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Castings/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CastingID,Nombre,FechaContratacion,EstadoActivo")] Casting casting)
        {
            if (ModelState.IsValid)
            {
                _context.Add(casting);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(casting);
        }

        // GET: Castings/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var casting = await _context.castings.FindAsync(id);
            if (casting == null)
            {
                return NotFound();
            }
            return View(casting);
        }

        // POST: Castings/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CastingID,Nombre,FechaContratacion,EstadoActivo")] Casting casting)
        {
            if (id != casting.CastingID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(casting);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CastingExists(casting.CastingID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(casting);
        }

        // GET: Castings/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var casting = await _context.castings
                .FirstOrDefaultAsync(m => m.CastingID == id);
            if (casting == null)
            {
                return NotFound();
            }

            return View(casting);
        }

        // POST: Castings/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var casting = await _context.castings.FindAsync(id);
            if (casting != null)
            {
                _context.castings.Remove(casting);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CastingExists(int id)
        {
            return _context.castings.Any(e => e.CastingID == id);
        }
    }
}
